package com.app.service;

import java.util.List;

import com.app.model.Post;

public interface PostServiceI 
{
	public void savePost(Post p);
	public List<Post> getPost();
	public List<Post> logincheck(long id,String password);
	public void deletePost(long id);
	public Post editPost(String content, long id);
	public void updatePost(Post s);
}
