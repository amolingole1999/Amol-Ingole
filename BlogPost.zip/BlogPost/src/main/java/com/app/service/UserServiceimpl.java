package com.app.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.app.model.Post;

import com.app.repositary.UserRepositary;
@Service
public class UserServiceimpl implements PostServiceI
{
	@Autowired
	UserRepositary sr;
	@Override
	public void savePost(Post p) {
		
		  sr.save(p);
	}

	@Override
	public List<Post> getPost() {
		
		return (List<Post>) sr.findAll();
	}

	@Override
	public List<Post> logincheck(long id, String password) {
		
		return sr.findByIdAndPassword(id,password);
	}

	@Override
	public void deletePost(long id) {
		sr.deleteById(id);
		
	}

	
	@Override
	public void updatePost(Post s) {
		sr.save(s);
		
	}

	@Override
	public Post editPost(String content, long id) {
		Optional<Post> op=sr.findById(id);
	     if(op.isPresent()) {
	    	 Post s= op.get(); 
	    	  return s;
	     }
	     else {
	    	 return null;
	     }
	}

}
