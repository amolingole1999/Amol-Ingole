package com.app.repositary;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.app.model.Post;


public interface UserRepositary extends CrudRepository<Post, Long>
{
    // custom method
	public List<Post> findByIdAndPassword(long id,String password);
}
