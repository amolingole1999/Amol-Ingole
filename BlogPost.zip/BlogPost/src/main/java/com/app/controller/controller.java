package com.app.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.app.model.Post;
import com.app.service.UserServiceimpl;


@Controller
public class controller 
{
	@Autowired
	UserServiceimpl us;
	@RequestMapping(value = "/")
	public String preLogin() {
		return "login";
	}
	
	@RequestMapping(value = "/register")
	public String preRegister() {
		return "register";
	}
	@RequestMapping(value = "/save")
	public String saveStudent(@ModelAttribute Post u) {
		us.savePost(u);
		return "login";
	}
	@RequestMapping(value = "/login")
	public String logincheck(@ModelAttribute Post u,Model m) {
		List<Post> list=us.logincheck(u.getId(),u.getPassword());
		if(!list.isEmpty()) {
			m.addAttribute("data", list);
			return "success";
		}
		else {
			
			return "login";
		}
	}
}
